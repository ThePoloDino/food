from flask import Flask, request, render_template
import openai
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Set your OpenAI API key
openai.api_key = os.getenv('OPENAI_API_KEY')

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/find_recipes', methods=['POST'])
def find_recipes():
    ingredients = request.form.get('ingredients')
    if not ingredients:
        return "Please enter some ingredients.", 400

    try:
        response = openai.Completion.create(
            model="gpt-3.5-turbo-instruct",
            prompt=f"Give me foods that can be made with the following make sure that this makes sense and will not taste bad. Make sure that you put in a Lot of details and that you make it sound soo good that the user will want to make it. : {ingredients}",
            max_tokens=100
        )
        recipe_suggestions = response.choices[0].text.strip()
        return render_template('results.html', recipes=recipe_suggestions)
    except Exception as e:
        return f"An error occurred: {e}", 500

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000)
